### Steps to reproduce
1. 
2. 
3. 

Demo: http://jsfiddle.net/cwhgLcjv/ (fork this example and update the link)

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead
